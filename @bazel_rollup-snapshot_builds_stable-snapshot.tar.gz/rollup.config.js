// Note: we cannot require() any plugins here because the user may not have any installed

module.exports = {
  output: {},
  plugins: [],
};
