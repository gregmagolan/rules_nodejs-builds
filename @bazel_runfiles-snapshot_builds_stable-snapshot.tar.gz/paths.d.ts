export declare const BAZEL_OUT_REGEX: RegExp;
