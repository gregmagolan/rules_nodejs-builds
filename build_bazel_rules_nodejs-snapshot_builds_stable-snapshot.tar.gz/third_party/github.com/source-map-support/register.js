require('./').install({environment: 'node'})
